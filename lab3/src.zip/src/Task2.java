import java.util.*;

public class Task2 {

    public static void main(String[] args) {
        boolean user = true;
        if (!user) {
            for (int h = 10000; h < 200000; h += 50000) {
                Random random = new Random();
                int n = h * 10; // Number of nodes
                int m = h * 10; // Number of edges

                List<List<Integer>> graph = new ArrayList<>();
                for (int i = 0; i < n; i++) {
                    graph.add(new ArrayList<>());
                }

                for (int i = 0; i < m; i++) {
                    int u = random.nextInt(n);
                    int v = random.nextInt(n);
                    if (u != v) {
                        graph.get(u).add(v);
                        graph.get(v).add(u);
                    }
                }
                long startTime = System.currentTimeMillis();
                List<Integer> result = Task2.bfs(graph, 0);
                System.out.println(n + ";" + m + ";" + (System.currentTimeMillis() - startTime));
            }
        } else {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter the number of nodes:");
            int n = scanner.nextInt();
            System.out.println("Enter the number of edges:");
            int m = scanner.nextInt();

            List<List<Integer>> graph = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                graph.add(new ArrayList<>());
            }

            for (int i = 0; i < m; i++) {
                System.out.println("Enter edge " + (i + 1) + ":");
                int u = scanner.nextInt();
                int v = scanner.nextInt();
                graph.get(u).add(v);
                graph.get(v).add(u);
            }

            List<Integer> result = Task2.bfs(graph, 0);
            System.out.println(result);
        }


    }


    public static List<Integer> bfs(List<List<Integer>> graph, int start) {
        Queue<Integer> queue = new LinkedList<>();
        Set<Integer> visited = new HashSet<>();

        queue.add(start);
        visited.add(start);

        while (!queue.isEmpty()) {
            int node = queue.remove();

            for (int neighbor : graph.get(node)) {
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    queue.add(neighbor);
                }
            }
        }

        return new ArrayList<>(visited);
    }
}
