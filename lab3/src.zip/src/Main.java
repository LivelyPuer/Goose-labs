public class Main {
    public static void main(String[] args) {
        BinaryHeap binaryHeap = new BinaryHeap(10);


        binaryHeap.insertNode(5);
        binaryHeap.insertNode(3);
        binaryHeap.insertNode(8);
        binaryHeap.insertNode(10);
        binaryHeap.insertNode(12);
        binaryHeap.insertNode(7);
        binaryHeap.insertNode(15);
        binaryHeap.insertNode(20);
        binaryHeap.insertNode(4);
        binaryHeap.insertNode(18);


        binaryHeap.printHeap();

        binaryHeap.changeNode(3, 15);
        binaryHeap.printHeap();


        Integer removedValue = binaryHeap.removeNode(5);
        System.out.println("\nRemoved value: " + removedValue);
        binaryHeap.printHeap();
    }
}